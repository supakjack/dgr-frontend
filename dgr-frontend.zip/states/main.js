const $state = {
    user: {
        username: '',
        token: '',
        role: '',
        area_id: '',
        title: '',
        firstname: '',
        id: '',
        lastname: ''
    },
    path: '',
    loading: ''
}

